 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\EMA\ExportFolder\0\87674\Output\KiCad\KiCad\symbols.lib
 
 
After you have used Ultra Librarian to export library:
**************************************************
**To import your new library symbols into KiCad:**
**************************************************
1. Open KiCad.
2. On the program/tool list, go to Eeschema.
3. Select *Preferences* from the menu bar then select *Library*.
4. Click *Add* and choose the newly exported *.LIB* file.
5. You have now successfully imported your new symbol library!

**************************************************************
**To import your new library footprints/patterns into KiCad:**
**************************************************************
1. Open KiCad.
2. On the program/tool list, go to Pcbnew.
3. Follow the same steps as you would importing symbols, only this time select the *.kicad_mod* file.
4. You have now successfully imported your new footprint/pattern.




 
 
Component "MSP430G2231IPW14R" renamed to "MSP430G2231IPW14R"
