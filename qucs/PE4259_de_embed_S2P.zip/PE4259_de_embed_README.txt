PE4259_RFC_RF1_de_embed.s2p  =  S11 is RFC / S22 is RF1  /RF1 ENABLED
PE4259_RFC_RF2_de_embed.s2p  =  S11 is RFC / S22 is RF2  /RF2 ENABLED
PE4259_RF1_RF2_de_embed.s2p  =  S11 is RF1 w/ RFC terminated.  /S22 is RF2.  /RF1 ENABLED